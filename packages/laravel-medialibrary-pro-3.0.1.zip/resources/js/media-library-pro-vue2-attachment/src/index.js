export { default as MediaLibraryAttachment } from './MediaLibraryAttachment.vue';
