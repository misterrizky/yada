## Upgrading

You'll find upgrade instructions [in our docs](https://spatie.be/docs/laravel-medialibrary/v10/handling-uploads-with-media-library-pro/upgrading).
